#!/bin/bash -e

apt-get install udhcpd hostapd

mv .etc-default-hostapd /etc/default/.hostapd.AP
mv .etc-hostapd-hostapd.conf /etc/hostapd/.hostapd.conf.AP
mv .etc-udhcpd.conf /etc/.udhcpd.conf.AP
mv .etc-default-udhcpd /etc/default/.udhcpd.AP
mv .etc-network-interfaces /etc/network/.interfaces.AP

mv /etc/default/hostapd /etc/default/.hostapd.ORG
mv /etc/udhcpd.conf /etc/.udhcpd.conf.ORG
mv /etc/default/udhcpd /etc/default/.udhcpd.ORG
mv /etc/network/interfaces /etc/network/.interfaces.ORG

rm ./setup.sh
mv .AP.sh AP.sh

./AP.sh off

cat readme.txt


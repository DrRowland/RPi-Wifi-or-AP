Install Access Point configuration with:
   sudo ./setup.sh

Then, to switch between configurations:
   sudo ./AP.sh off
or
   sudo ./AP.sh off
and reboot.

